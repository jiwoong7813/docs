TN40xx NIC Driver Version 1.1 

  
Support��
-Windows 7 32/64 bit 
-Windows 8.1 32/64 bit
-Windows 10 Pro Insider Preview 64 bit
-Windows Server 2008 R2
-Windows Server 2012
-Windows Server 2012 R2
-Windows Hyper-V

Windows install��
Device Manager/Network Adapter
 Updata Driver Software/Browse the computer to find the driver software/find(TN40xx_4.4.405.156.WHQL)

#########################################################################
TN40xx Support Linux Driver Version��
-tn40xx-0.3.6.14                  support 2.6.32 up to 4.x

Linux driver install��
unzip tn40xx-0.3.6.14.tgz 
cd /tn40xx-0.3.6.14
make clean
make
make install

Note: copy the file to the local disk before installation

#########################################################################
TN40xx Support Vmware Driver Version��
-vmware_esx5x_tn40xx-0.3.6.12.1   support vmware 5.x, vmware 6.0
-vmware_esx6x_tn40xx-1.0.2        support vmware 6.0, vmware 6.5


#########################################################################
TN40xx Support MAC OS Driver Version��
-tn40xx_10.10-1.48                support 10.10.3 or previous versions
-tn40xx_10.11-1.50                support 10.11.6 or previous versions
-tn40xx_10.12-1.52.2              support 10.12.6 or previous versions
